class History{
	int computerMove;
	int playerMove;
	String gameResult;
	int numberOfRounds;

	History(int computerMove, int playerMove, String gameResult, int numberOfRounds){
		this.computerMove = computerMove;
		this.playerMove = playerMove;
		this.gameResult = gameResult;
		this.numberOfRounds = numberOfRounds;
	}
}