import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayList;

class RockPaperScissorsGame{

	// Result (Done)
	// Score (Done)
	// Rounds (Done)
	// Update Score (Done)
	// History (Done)

	public static Scanner scanner = new Scanner(System.in);
	public static int random = ThreadLocalRandom.current().nextInt(1, 3);
	// public static Score score = new Score();
	// public static Score updateScores = new Score();
	public static ArrayList<Score> allScoresFromCurrentRound = new ArrayList<>();
	public static ArrayList<History> gameHistory = new ArrayList<>();

	public static void main(String[] args) {
		System.out.println("Welcome to Rock Paper Scissors Game!");
		System.out.println("====================================");

		playGame();
	}

	static boolean stopGame(int playerChoice){
		return playerChoice == 4;
	}

	static int chooseValidOption(int playerChoice){	
		while(playerChoice > 4 || playerChoice < 1){
			System.out.println("Try again! Please choose between 1 to 4.");
			playerChoice = scanner.nextInt();
		}
		return playerChoice;
	}

	static void playGame(){

		outer:
		while(true){
			System.out.println("Type \"0\" to play game.");
			int startGame = scanner.nextInt();	

			int round = 1;
			boolean continuePlayingGame = true;

			if(startGame == 0){
				to:
				while(continuePlayingGame){
					System.out.println("Round : " + round);

					boolean playingCurrentRound = true;

					while(playingCurrentRound){
						System.out.println("Game is starting...");
						System.out.println("====================");
						System.out.println("Choose one option.");
						System.out.println("1. Rock");
						System.out.println("2. Paper");
						System.out.println("3. Scissors");
						System.out.println("4. Quit Game!");
						System.out.println("===============");

						int playerChoice = scanner.nextInt();
						scanner.nextLine();

						String result = "";
						String finalResult = "";

						if(stopGame(playerChoice)){
							playingCurrentRound = false;

							System.out.print("Round : " + round + " ended. " + "Do you want to start the next round? (yes/no) : ");
							String answer = scanner.nextLine();
							System.out.println();

							if(answer.equalsIgnoreCase("Yes")){
								var updateScores = new Score();
								allScoresFromCurrentRound.clear(); // can't include argument
								round++;
								continue to;								
							}
							else{
								continuePlayingGame = false;

								showHistory();

								System.out.println("Thanks for playing.");
								break outer;
							}
						}

						playerChoice = chooseValidOption(playerChoice);

						// score
						var score = new Score();
						score.wins = 0;
						score.losses = 0;
						score.ties = 0;				

						if(playerChoice == 1){
							if(random == 1){
								result = "Tie";
								if(playerChoice == random){
									finalResult = "Tie";
								}
							}
							else if(random == 2){
								result = "Lose";
								if(playerChoice == 1 && random == 2){
									finalResult = "Computer Wins";
								}							
							}
							else if(random == 3){
								result = "Win";
								if(playerChoice == 1 && random == 3){
									finalResult = "Player Wins";
								}
							}
						}
						else if(playerChoice == 2){
							if(random == 1){
								result = "Win";
								if(playerChoice == 2 && random == 1){
									finalResult = "Player Wins";
								}
							}
							else if(random == 2){
								result = "Tie";
								if(playerChoice == 2 && random == 2){
									finalResult = "Tie";
								}
							}
							else if(random == 3){
								result = "Lose";
								if(playerChoice == 2 && random == 3){
									finalResult = "Computer Wins";
								}
							}
						}
						else if(playerChoice == 3){
							if(random == 1){
								result = "Lose";
								if(playerChoice == 3 && random == 1){
									finalResult = "Computer Wins";
								}
							}
							else if(random == 2){
								result = "Win";
								if(playerChoice == 3 && random == 2){
									finalResult = "Player Wins";
								}
							}
							else if(random == 3){
								result = "Tie";
								if(playerChoice == 3 && random == 3){
									finalResult = "Tie";
								}
							}
						}

						totalScores(result, score);

						System.out.println("Player Choice : " + changeToString(playerChoice) + " || " + "Computer Choice : " + changeToString(random));
						System.out.println("Game Result : " + finalResult);

						allScoresFromCurrentRound.add(score);

						// updateScores
						var updateScores = new Score();
						int wins;
						int losses;
						int ties;

						for(int i = 0; i < allScoresFromCurrentRound.size(); i++){
							Score s = allScoresFromCurrentRound.get(i);

						    updateScores.wins += s.wins;
						    updateScores.losses += s.losses;
						    updateScores.ties += s.ties;
						}

						System.out.println("Round " + round + " => " + "Wins : " + updateScores.wins + ", Losses : " + updateScores.losses + ", Ties : " + updateScores.ties + "\n");
						gameHistory.add(new History(random, playerChoice, result, round));
					}
				}	
			}		
			else{
				System.out.println("Invalid Input! Please type \"0\" to start.");
			}
		}
	}

	// Score
	static void totalScores(String result, Score score){
		if(result.equals("Win")){
			score.wins++;
		}
		else if(result.equals("Lose")){
			score.losses++;
		}
		else if(result.equals("Tie")){
			score.ties++;
		}
	}

	// History
	static void showHistory(){
		for(int i = 0; i < gameHistory.size(); i++){
			History h = gameHistory.get(i);
			
			String outcome = "";

			if(h.gameResult.equals("Wins")){
				outcome = "Player Wins - " + WinLoseHistory(h.playerMove, h.computerMove);
			}
			else if(h.gameResult.equals("Loses")){
				outcome = "Computer Wins - " + WinLoseHistory(h.computerMove, h.playerMove);
			}
			else{
				outcome = "Tie - " + changeToString(h.playerMove) + " vs " + changeToString(h.computerMove);
			}
			System.out.println("Round " + h.numberOfRounds + ": Player chose " + changeToString(h.playerMove) + ", Computer chose " + changeToString(h.computerMove) + " => Result: " + outcome);
		}
	}

	static String WinLoseHistory(int win, int lose){
	    if(win == 1 && lose == 3){
	    	return "Rock beats Scissors";
	    } 
	    else if(win == 3 && lose == 2){
	    	return "Scissors beats Paper";
	    } 
	    else if(win == 2 && lose == 1){
	    	return "Paper beats Rock";
	    }
	    return "";
	}

	static String changeToString(int change){
		if(change == 1){
			return "Rock";
		}
		else if(change == 2){
			return "Paper";
		}
		else if(change == 3){
			return "Scissors";
		}
		return "";
	}
}