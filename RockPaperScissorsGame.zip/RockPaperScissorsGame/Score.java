class Score{
	int wins;
	int losses;
	int ties;
}